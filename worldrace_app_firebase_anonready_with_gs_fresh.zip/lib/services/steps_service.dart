import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:pedometer/pedometer.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/level_info.dart';
class StepsService extends ChangeNotifier {
  int todaySteps = 0;
  int weekSteps = 0;
  int monthSteps = 0;
  int totalSteps = 0;
  StreamSubscription<StepCount>? _sub;
  int? _baseAtDayStart;
  Timer? _debounce;
  Future<void> init() async {
    await _loadLocal();
    try { _sub = Pedometer.stepCountStream.listen(_onStep, onError: (e) {}); } catch (_) {}
    Timer.periodic(const Duration(seconds: 1), (_) { notifyListeners(); });
  }
  void _onStep(StepCount ev) {
    if (_baseAtDayStart == null) _baseAtDayStart = ev.steps;
    final today = ev.steps - (_baseAtDayStart ?? 0);
    todaySteps = today < 0 ? 0 : today;
    totalSteps = totalSteps + 1;
    weekSteps = todaySteps; monthSteps = todaySteps;
    _persist(); _schedulePush(); notifyListeners();
  }
  void _schedulePush() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(seconds: 2), () async {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        final lvl = LevelInfo.fromTotal(totalSteps);
        await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
          'totalSteps': totalSteps, 'level': lvl.level, 'iconKey': lvl.iconKey,
          'updatedAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      }
    });
  }
  Future<void> _persist() async { final sp = await SharedPreferences.getInstance(); await sp.setInt('wr_total', totalSteps); }
  Future<void> _loadLocal() async { final sp = await SharedPreferences.getInstance(); totalSteps = sp.getInt('wr_total') ?? 0; }
  LevelInfo get level => LevelInfo.fromTotal(totalSteps);
  @override void dispose() { _sub?.cancel(); _debounce?.cancel(); super.dispose(); }
}
