import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
class AuthService extends ChangeNotifier {
  bool initialized = false;
  String? uid;
  String? displayName;
  String? photoUrl;
  Future<void> init() async {
    final auth = FirebaseAuth.instance;
    User? user = auth.currentUser;
    if (user == null) {
      final cred = await auth.signInAnonymously();
      user = cred.user;
    }
    uid = user?.uid;
    displayName = user?.isAnonymous == true ? 'Anonymous' : (user?.displayName ?? 'User');
    photoUrl = user?.photoURL;
    await FirebaseFirestore.instance.collection('users').doc(uid).set({
      'uid': uid, 'displayName': displayName, 'photoUrl': photoUrl,
      'totalSteps': 0, 'level': 1, 'iconKey': 'starter',
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    initialized = true; notifyListeners();
  }
  bool get isSignedIn => uid != null;
}
