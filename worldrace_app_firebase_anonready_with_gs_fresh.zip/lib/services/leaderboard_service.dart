import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/leaderboard_entry.dart';
class LeaderboardService {
  final _db = FirebaseFirestore.instance;
  Stream<List<LeaderboardEntry>> top5000() {
    return _db.collection('users').orderBy('totalSteps', descending: true).limit(5000).snapshots()
      .map((snap) => snap.docs.map((d) => LeaderboardEntry.fromMap({'uid': d.id, ...d.data()})).toList());
  }
}
