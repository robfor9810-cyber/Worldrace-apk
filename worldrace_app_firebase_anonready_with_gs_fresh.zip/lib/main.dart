import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services/auth_service.dart';
import 'services/steps_service.dart';
import 'services/leaderboard_service.dart';
import 'ui/home_shell.dart';
import 'package:firebase_core/firebase_core.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const WorldraceApp());
}

class WorldraceApp extends StatelessWidget {
  const WorldraceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()..init()),
        ChangeNotifierProvider(create: (_) => StepsService()..init()),
        Provider(create: (_) => LeaderboardService()),
      ],
      child: MaterialApp(
        title: 'Worldrace',
        theme: ThemeData(useMaterial3: true),
        home: const HomeShell(),
      ),
    );
  }
}
