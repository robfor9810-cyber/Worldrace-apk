import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/steps_service.dart';
import '../models/level_info.dart';
class LevelPage extends StatelessWidget {
  const LevelPage({super.key});
  @override
  Widget build(BuildContext context) {
    final steps = context.watch<StepsService>();
    final LevelInfo current = LevelInfo.fromTotal(steps.totalSteps);
    final LevelInfo next = current.next();
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(image: AssetImage('assets/maps/map_placeholder.png'), fit: BoxFit.cover, opacity: 0.08),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Level', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Row(children: [
              _IconBox(label: 'Nuvarande', iconKey: current.iconKey, level: current.level),
              const SizedBox(width: 16),
              _IconBox(label: 'Nästa', iconKey: next.iconKey, level: next.level),
            ]),
            const SizedBox(height: 16),
            Text('Steg kvar till Level ${next.level}: ${next.requiredTotalSteps - steps.totalSteps}'),
          ]),
        ),
      ),
    );
  }
}
class _IconBox extends StatelessWidget {
  final String label; final String iconKey; final int level;
  const _IconBox({required this.label, required this.iconKey, required this.level});
  @override
  Widget build(BuildContext context) {
    return Expanded(child: Card(child: Padding(padding: EdgeInsets.all(12), child: Column(children: [
      Text(label), SizedBox(height: 8),
      Container(width: 64, height: 64, decoration: BoxDecoration(border: Border.all(), borderRadius: BorderRadius.circular(8)), alignment: Alignment.center, child: Text(iconKey)),
      SizedBox(height: 8), Text('Level $level'),
    ]))));
  }
}
