import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/leaderboard_service.dart';
import '../models/leaderboard_entry.dart';
class WorldStepsPage extends StatelessWidget {
  const WorldStepsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final service = context.read<LeaderboardService>();
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(image: AssetImage('assets/maps/map_placeholder.png'), fit: BoxFit.cover, opacity: 0.08),
      ),
      child: SafeArea(
        child: StreamBuilder<List<LeaderboardEntry>>(
          stream: service.top5000(),
          builder: (context, snap) {
            if (snap.hasError) return const Center(child: Text('Error loading leaderboard'));
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final rows = snap.data!;
            if (rows.isEmpty) return const Center(child: Text('Inga användare ännu. Ta en promenad!'));
            return ListView.builder(
              itemCount: rows.length,
              itemBuilder: (context, i) {
                final e = rows[i];
                return ListTile(
                  leading: CircleAvatar(child: Text('${i+1}')),
                  title: Text(e.displayName),
                  subtitle: Text('Level ${e.level} • ${e.iconKey}'),
                  trailing: Text('${e.totalSteps} steps'),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
