import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
import 'my_steps_page.dart';
import 'world_steps_page.dart';
import 'level_page.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  final _pages = const [ MyStepsPage(), WorldStepsPage(), LevelPage(), ];
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Worldrace'),
        actions: [
          IconButton(
            icon: CircleAvatar(child: Text((auth.displayName?.isNotEmpty ?? false) ? auth.displayName![0] : '?')),
            onPressed: () async {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Kör anonymt nu – lägg till SHA-1 senare för Google-inloggning.')),
              );
            },
            tooltip: 'Sign in',
          )
        ],
      ),
      body: _pages[_index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.directions_walk), label: 'My Steps'),
          NavigationDestination(icon: Icon(Icons.public), label: 'World Steps'),
          NavigationDestination(icon: Icon(Icons.stacked_bar_chart), label: 'Level'),
        ],
      ),
    );
  }
}
