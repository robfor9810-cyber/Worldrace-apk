import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/steps_service.dart';
class MyStepsPage extends StatelessWidget {
  const MyStepsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final steps = context.watch<StepsService>();
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(image: AssetImage('assets/maps/map_placeholder.png'), fit: BoxFit.cover, opacity: 0.1),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('My Steps', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              _StatTile(title: 'Idag', value: steps.todaySteps.toString()),
              _StatTile(title: 'Denna vecka', value: steps.weekSteps.toString()),
              _StatTile(title: 'Denna månad', value: steps.monthSteps.toString()),
              _StatTile(title: 'Totalt', value: steps.totalSteps.toString()),
            ],
          ),
        ),
      ),
    );
  }
}
class _StatTile extends StatelessWidget {
  final String title; final String value;
  const _StatTile({required this.title, required this.value});
  @override
  Widget build(BuildContext context) {
    return Card(child: ListTile(title: Text(title), trailing: Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))));
  }
}
