class LeaderboardEntry {
  final String uid;
  final String displayName;
  final int totalSteps;
  final int level;
  final String iconKey;
  LeaderboardEntry({required this.uid, required this.displayName, required this.totalSteps, required this.level, required this.iconKey});
  factory LeaderboardEntry.fromMap(Map<String, dynamic> map) {
    return LeaderboardEntry(
      uid: map['uid'] as String,
      displayName: map['displayName'] ?? 'Anonymous',
      totalSteps: (map['totalSteps'] ?? 0) as int,
      level: (map['level'] ?? 1) as int,
      iconKey: map['iconKey'] ?? 'white',
    );
  }
}
