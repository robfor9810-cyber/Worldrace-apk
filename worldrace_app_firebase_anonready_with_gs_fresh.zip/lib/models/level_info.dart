class LevelInfo {
  final int level;
  final int requiredTotalSteps;
  final String iconKey;
  LevelInfo({required this.level, required this.requiredTotalSteps, required this.iconKey});
  static LevelInfo fromTotal(int total) {
    if (total >= 2000000) return LevelInfo(level: _calcLevel(total), requiredTotalSteps: 2000000, iconKey: 'metal');
    if (total >= 1000000) return LevelInfo(level: _calcLevel(total), requiredTotalSteps: 1000000, iconKey: 'wood');
    if (total >= 2500)    return LevelInfo(level: 3, requiredTotalSteps: 2500, iconKey: 'gray');
    if (total >= 1000)    return LevelInfo(level: 2, requiredTotalSteps: 1000, iconKey: 'white');
    return LevelInfo(level: 1, requiredTotalSteps: 0, iconKey: 'starter');
  }
  LevelInfo next() {
    if (level < 2) return LevelInfo(level: 2, requiredTotalSteps: 1000, iconKey: 'white');
    if (level < 3) return LevelInfo(level: 3, requiredTotalSteps: 2500, iconKey: 'gray');
    if (requiredTotalSteps < 1000000) return LevelInfo(level: 10, requiredTotalSteps: 1000000, iconKey: 'wood');
    if (requiredTotalSteps < 2000000) return LevelInfo(level: 20, requiredTotalSteps: 2000000, iconKey: 'metal');
    return LevelInfo(level: level + 1, requiredTotalSteps: requiredTotalSteps + 1000000, iconKey: 'legend');
  }
  static int _calcLevel(int total) {
    if (total < 2500) return total >= 1000 ? 2 : 1;
    if (total < 1000000) return 3 + (total - 2500) ~/ 50000;
    return 10 + (total - 1000000) ~/ 10000;
  }
}
